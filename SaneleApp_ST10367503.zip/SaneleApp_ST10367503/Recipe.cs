﻿using System.Collections.Generic;
using System.Linq;

namespace RecipeApp
{
    public class Recipe
    {
        public string Name { get; set; }
        public List<Ingredient> Ingredients { get; set; } = new List<Ingredient>();

        public int TotalCalories => Ingredients.Sum(i => i.Calories);
    }
}




