﻿using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace RecipeApp
{
    public partial class MainWindow : Window
    {
        public ObservableCollection<Recipe> Recipes { get; set; } = new ObservableCollection<Recipe>();
        private Recipe currentRecipe;

        public MainWindow()
        {
            InitializeComponent();
            RecipeListBox.ItemsSource = Recipes;
        }

        private void AddRecipeButton_Click(object sender, RoutedEventArgs e)
        {
            string recipeName = RecipeNameTextBox.Text;
            if (!string.IsNullOrEmpty(recipeName))
            {
                currentRecipe = new Recipe { Name = recipeName };
                Recipes.Add(currentRecipe);
                Recipes = new ObservableCollection<Recipe>(Recipes.OrderBy(r => r.Name));
                RecipeListBox.ItemsSource = Recipes;

                RecipeNameTextBox.Clear();
            }
            else
            {
                MessageBox.Show("Please enter a recipe name.");
            }
        }

        private void AddIngredientButton_Click(object sender, RoutedEventArgs e)
        {
            if (currentRecipe == null)
            {
                MessageBox.Show("Please enter a recipe name first.");
                return;
            }

            string ingredientName = IngredientNameTextBox.Text;
            if (int.TryParse(IngredientCaloriesTextBox.Text, out int calories) &&
                IngredientFoodGroupComboBox.SelectedItem is ComboBoxItem selectedFoodGroup)
            {
                Ingredient ingredient = new Ingredient
                {
                    Name = ingredientName,
                    Calories = calories,
                    FoodGroup = selectedFoodGroup.Content.ToString()
                };
                currentRecipe.Ingredients.Add(ingredient);

                IngredientNameTextBox.Clear();
                IngredientCaloriesTextBox.Clear();
                IngredientFoodGroupComboBox.SelectedIndex = -1;

                if (currentRecipe.TotalCalories > 300)
                {
                    MessageBox.Show("Total calories exceed 300!");
                }

                // Update the displayed recipe list
                RecipeListBox.ItemsSource = Recipes.OrderBy(r => r.Name).ToList();
            }
            else
            {
                MessageBox.Show("Please enter valid ingredient details.");
            }
        }

        private void FilterButton_Click(object sender, RoutedEventArgs e)
        {
            string ingredient = IngredientTextBox.Text.ToLower();
            string foodGroup = (FoodGroupComboBox.SelectedItem as ComboBoxItem)?.Content.ToString();
            bool maxCaloriesParsed = int.TryParse(MaxCaloriesTextBox.Text, out int maxCalories);

            var filteredRecipes = Recipes.Where(r =>
                (string.IsNullOrEmpty(ingredient) || r.Ingredients.Any(i => i.Name.ToLower().Contains(ingredient))) &&
                (foodGroup == "All" || r.Ingredients.Any(i => i.FoodGroup == foodGroup)) &&
                (!maxCaloriesParsed || r.TotalCalories <= maxCalories))
                .ToList();

            RecipeListBox.ItemsSource = filteredRecipes;
        }

        private void RecipeListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (RecipeListBox.SelectedItem != null && RecipeListBox.SelectedItem is Recipe selectedRecipe)
            {
                SelectedRecipeDetails.Text = $"Name: {selectedRecipe.Name}\nTotal Calories: {selectedRecipe.TotalCalories}\nIngredients:\n" +
                                             string.Join("\n", selectedRecipe.Ingredients.Select(i => $"{i.Name} ({i.Calories} calories, {i.FoodGroup})"));
            }
        }
    }
}



